﻿namespace AgeGender
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int age = int.Parse(Console.ReadLine());
            string gender = Console.ReadLine();
            Console.WriteLine((gender.ToLower() + (age >= 16 ? "+" : "-"))  switch
            {
                "m+" => "Mr.",
                "m-" => "Master",
                "f-" => "Miss",
                "f+" => "Ms."
            });
        }
    }
}